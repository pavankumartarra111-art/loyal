# Celestial Transmutation

A Pen created on CodePen.

Original URL: [https://codepen.io/VoXelo/pen/yygKOVy](https://codepen.io/VoXelo/pen/yygKOVy).

Four conceptual planets. One fluid transformation system with sweeping shader energy and volumetric particles.