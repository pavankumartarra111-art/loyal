# Ocean Shader 6-Scene Day Cycle (WebGL GLSL)

A Pen created on CodePen.

Original URL: [https://codepen.io/Tarra-pavan-kumar/pen/QwpxKNZ](https://codepen.io/Tarra-pavan-kumar/pen/QwpxKNZ).

A full-screen WebGL ocean shader cycling through six atmospheric scenes: Pre-Dawn, Dawn, Midday, Dusk, Storm, and Night — all driven by a single GLSL fragment shader with no external libraries.

Scroll to transition between scenes. Features include:

- Procedural sky with per-scene gradient palettes and sun arc animation
- Realistic ocean surface with Fresnel reflections, subsurface scatter, specular highlights, and water glitter
- Dynamic sun disk with multi-layer corona/halo and horizon atmospheric glow
- Moon disk, corona, and multi-halo reflections on the water
- Tiered star field with per-star atmospheric scintillation
- Animated clouds blending from clear to storm coverage
- Lightning system with branching bolts, sheet glow, and water reflection
- Adaptive render quality scaling to maintain 60 fps
- Smooth scroll spring with inertia and scene looping
- Film grain post-processing and photographic tone mapping

Built with: raw WebGL 1.0 · GLSL ES 1.00 · Space Grotesk + Space Mono (Google Fonts) · zero dependencies